<?php

$hashGenerado = "";
$resultadoValidacion = "";

if (isset($_POST["generar_hash"])) {

    $password = $_POST["password_generar"] ?? "";

    if (!empty($password)) {
        $hashGenerado = password_hash(
            $password,
            PASSWORD_DEFAULT
        );
    }
}

if (isset($_POST["validar_hash"])) {

    $password = $_POST["password_validar"] ?? "";
    $hash = $_POST["hash_validar"] ?? "";

    if (
        !empty($password) &&
        !empty($hash)
    ) {

        if (password_verify($password, $hash)) {

            $resultadoValidacion =
                "✅ La contraseña coincide con el hash.";

        } else {

            $resultadoValidacion =
                "❌ La contraseña NO coincide con el hash.";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Generador de Hash</title>

    <link
        rel="stylesheet"
        href="css/estilos.css">
</head>
<body>

<div class="contenedor">

    <h1>Generador y Validador de Hash</h1>

    <hr>

    <h2>Generar Hash</h2>

    <form method="POST">

        <input
            type="text"
            name="password_generar"
            placeholder="Contraseña"
            required>

        <button
            type="submit"
            name="generar_hash">

            Generar Hash

        </button>

    </form>

    <?php if (!empty($hashGenerado)): ?>

        <br>

        <div class="exito">

            <strong>Hash generado:</strong>

            <br><br>

            <code>
                <?= htmlspecialchars($hashGenerado) ?>
            </code>

        </div>

    <?php endif; ?>

    <hr>

    <h2>Validar Hash</h2>

    <form method="POST">

        <input
            type="text"
            name="password_validar"
            placeholder="Contraseña"
            required>

        <textarea
            name="hash_validar"
            placeholder="Pegue aquí el hash"
            rows="5"
            style="
                width:100%;
                margin-bottom:15px;
                border-radius:12px;
                padding:12px;
            "
            required></textarea>

        <button
            type="submit"
            name="validar_hash">

            Validar Hash

        </button>

    </form>

    <?php if (!empty($resultadoValidacion)): ?>

        <br>

        <?php if (str_contains($resultadoValidacion, "✅")): ?>

            <div class="exito">
                <?= $resultadoValidacion ?>
            </div>

        <?php else: ?>

            <div class="error">
                <?= $resultadoValidacion ?>
            </div>

        <?php endif; ?>

    <?php endif; ?>

    <br>

    <a href="dashboard.php">
        Volver al Dashboard
    </a>

</div>

</body>
</html>