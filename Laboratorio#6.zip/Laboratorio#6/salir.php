<?php
session_start();

require_once "clases/Logger.php";

if (isset($_SESSION["autenticado"])) {

    $correo =
        $_SESSION["correo_login"]
        ?? $_SESSION["correo_registrado"]
        ?? "desconocido";

    Logger::registrar(
        $correo,
        "Cierre de sesión",
        "exitoso"
    );

} else {

    Logger::registrar(
        "sin_sesion",
        "Acceso directo a salir.php",
        "fallido"
    );
}

session_unset();
session_destroy();

header("Location: login.php");
exit;