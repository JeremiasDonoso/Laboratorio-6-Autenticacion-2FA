<?php
session_start();

if (
    !isset($_SESSION["autenticado"]) ||
    !isset($_SESSION["2fa_validado"])
) {
    header("Location: login.php");
    exit;
}

$nombre = $_SESSION["nombre_usuario"] ?? "Usuario";
$correo = $_SESSION["correo_login"] ?? ($_SESSION["correo_registrado"] ?? "");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Seguro</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

<div class="contenedor">
    <h1>Dashboard Seguro</h1>

    <p>Bienvenido, <strong><?= htmlspecialchars($nombre); ?></strong>.</p>

    <p>Has iniciado sesión correctamente usando autenticación de dos factores.</p>

    <?php if (!empty($correo)): ?>
        <p><strong>Correo:</strong> <?= htmlspecialchars($correo); ?></p>
    <?php endif; ?>

    <a href="hash.php" class="boton">Ir a Generador de Hash</a>

    <br><br>

    <a href="salir.php">Cerrar sesión</a>
</div>

</body>
</html>