<?php
session_start();

require_once "clases/CSRFProtection.php";
require_once "clases/RegistroUsuario.php";
require_once "clases/Auth2FA.php";
require_once "clases/Logger.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    CSRFProtection::verificarFormulario();

    $correo = $_POST["correo"] ?? "";
    $password = $_POST["password"] ?? "";

    $registro = new RegistroUsuario();
    $usuario = $registro->obtenerPorCorreo($correo);


    
    if ($usuario && password_verify($password, $usuario["password_hash"])) {

        $_SESSION["usuario_id"] = $usuario["id"];
        $_SESSION["nombre_usuario"] = $usuario["nombre"];
        $_SESSION["correo_login"] = $usuario["correo"];

        if ((int)$usuario["fa_confirmado"] === 0) {

            $auth2fa = new Auth2FA();

            $_SESSION["fase_registro_2fa"] = true;
            $_SESSION["correo_registrado"] = $usuario["correo"];
            $_SESSION["secret_2fa"] = $usuario["secret_2fa"];
            $_SESSION["qr_2fa"] = $auth2fa->generarQR($usuario["correo"], $usuario["secret_2fa"]);

            Logger::registrar(
                $usuario["correo"],
                "Login correcto, pendiente de verificación 2FA",
                "exitoso"
            );

            header("Location: verificar_2fa.php");
            exit;
        }

        $_SESSION["login_pendiente_2fa"] = true;
        $_SESSION["secret_login_2fa"] = $usuario["secret_2fa"];

        header("Location: verificar_2fa.php");
        exit;

    } else {
        $error = "Correo o contraseña incorrectos.";
        
        Logger::registrar(
            $correo,
            "Intento de login fallido",
            "fallido"
        );
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login 2FA</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

<div class="contenedor">
    <h1>Iniciar Sesión</h1>

    <?php if (!empty($error)): ?>
        <p class="error"><?= htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <?= CSRFProtection::campoHidden(); ?>

        <input type="email" name="correo" placeholder="Correo electrónico" required>

        <input type="password" name="password" placeholder="Contraseña" maxlength="16" required>

        <button type="submit">Continuar</button>
    </form>

    <p>
        ¿No tienes cuenta?
        <a href="registro.php">Registrarse</a>
    </p>
</div>

</body>
</html>