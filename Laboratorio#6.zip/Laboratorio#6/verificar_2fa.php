<?php
session_start();

require_once "clases/CSRFProtection.php";
require_once "clases/Auth2FA.php";
require_once "clases/Logger.php";

$auth2fa = new Auth2FA();

$error = "";

$mostrarQR = isset($_SESSION["fase_registro_2fa"]);
$correo = $_SESSION["correo_registrado"] ?? ($_SESSION["correo_login"] ?? "");
$qr = $_SESSION["qr_2fa"] ?? "";
$secret = $_SESSION["secret_2fa"] ?? "";

if (
    !isset($_SESSION["fase_registro_2fa"]) &&
    !isset($_SESSION["login_pendiente_2fa"])
) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    CSRFProtection::verificarFormulario();

    $codigo = $_POST["codigo_2fa"] ?? "";

    if (isset($_SESSION["fase_registro_2fa"])) {
        $secret = $_SESSION["secret_2fa"];
    } else {
        $secret = $_SESSION["secret_login_2fa"];
    }

    if ($auth2fa->verificarCodigo($secret, $codigo)) {
        
        if (isset($_SESSION["fase_registro_2fa"])) {
            $auth2fa->confirmarActivacion($_SESSION["usuario_id"]);
        }
        
        unset($_SESSION["fase_registro_2fa"]);
        unset($_SESSION["login_pendiente_2fa"]);

        $_SESSION["2fa_validado"] = true;
        $_SESSION["autenticado"] = true;

        Logger::registrar(
            $correo,
            "Código 2FA validado correctamente",
            "exitoso"
        );

        header("Location: dashboard.php");
        exit;

    } else {
        $error = "Código 2FA incorrecto. Intente nuevamente.";

        Logger::registrar(
            $correo,
            "Código 2FA incorrecto",
            "fallido"
        );
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Verificación 2FA</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

<div class="contenedor">
    <h1>Verificación 2FA</h1>

    <?php if ($mostrarQR): ?>
        <p>Usuario registrado correctamente.</p>
        <p>Escanea este código QR con Google Authenticator.</p>

        <img src="<?= $qr; ?>" alt="Código QR 2FA" class="qr">

        <p><strong>Correo:</strong> <?= htmlspecialchars($correo); ?></p>

        <p><strong>Secret generado:</strong></p>
        <code><?= htmlspecialchars($secret); ?></code>

        <hr>

        <p>Después de escanear el QR, escribe el código generado por la app.</p>
    <?php else: ?>
        <p>Ingrese el código generado por Google Authenticator.</p>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <p class="error"><?= htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <form method="POST" action="verificar_2fa.php">
        <?= CSRFProtection::campoHidden(); ?>

        <input 
            type="text" 
            name="codigo_2fa" 
            placeholder="Código 2FA" 
            maxlength="6" 
            required
        >

        <button type="submit">Verificar código</button>
    </form>

    <br>

    <a href="salir.php">Cancelar</a>
</div>

</body>
</html>