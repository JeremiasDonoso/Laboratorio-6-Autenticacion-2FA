<?php

class Sanitizador
{
    public static function limpiarTexto($dato)
    {
        $dato = trim($dato);
        $dato = strip_tags($dato);
        $dato = htmlspecialchars($dato, ENT_QUOTES, 'UTF-8');
        return $dato;
    }

    public static function limpiarCorreo($correo)
    {
        $correo = trim($correo);
        $correo = filter_var($correo, FILTER_SANITIZE_EMAIL);
        return $correo;
    }

    public static function limpiarUsuario($usuario)
    {
        $usuario = trim($usuario);
        $usuario = strip_tags($usuario);
        $usuario = preg_replace('/[^a-zA-Z0-9_]/', '', $usuario);
        return $usuario;
    }

    public static function validarSexo($sexo)
    {
        return in_array($sexo, ['M', 'F']);
    }

    public static function limpiarCodigo2FA($codigo)
    {
        return preg_replace('/[^0-9]/', '', trim($codigo));
    }
}