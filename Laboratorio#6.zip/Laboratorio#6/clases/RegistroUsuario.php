<?php

require_once __DIR__ . "/Conexion.php";
require_once __DIR__ . "/Sanitizador.php";

class RegistroUsuario
{
    private $db;

    public function __construct()
    {
        $this->db = Conexion::conectar();
    }

    public function existeUsuario($usuario)
    {
        $sql = "SELECT id FROM usuarios WHERE usuario = :usuario";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":usuario", $usuario);
        $stmt->execute();

        return $stmt->rowCount() > 0;
    }

    public function existeCorreo($correo)
    {
        $sql = "SELECT id FROM usuarios WHERE correo = :correo";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":correo", $correo);
        $stmt->execute();

        return $stmt->rowCount() > 0;
    }

    public function registrar($nombre, $apellido, $usuario, $correo, $password, $confirmarPassword, $sexo)
    {
        $nombre = Sanitizador::limpiarTexto($nombre);
        $apellido = Sanitizador::limpiarTexto($apellido);
        $usuario = Sanitizador::limpiarUsuario($usuario);
        $correo = Sanitizador::limpiarCorreo($correo);
        $sexo = Sanitizador::limpiarTexto($sexo);

        if (
            empty($nombre) ||
            empty($apellido) ||
            empty($usuario) ||
            empty($correo) ||
            empty($password) ||
            empty($confirmarPassword) ||
            empty($sexo)
        ) {
            return [
                "estado" => false,
                "mensaje" => "Todos los campos son obligatorios."
            ];
        }

        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            return [
                "estado" => false,
                "mensaje" => "El correo electrónico no es válido."
            ];
        }

        if (!Sanitizador::validarSexo($sexo)) {
            return [
                "estado" => false,
                "mensaje" => "El sexo seleccionado no es válido."
            ];
        }

        if ($password !== $confirmarPassword) {
            return [
                "estado" => false,
                "mensaje" => "Las contraseñas no coinciden."
            ];
        }

        if (strlen($password) < 6) {
            return [
                "estado" => false,
                "mensaje" => "La contraseña debe tener mínimo 6 caracteres."
            ];
        }

        if ($this->existeUsuario($usuario)) {
            return [
                "estado" => false,
                "mensaje" => "El usuario ya está registrado."
            ];
        }

        if ($this->existeCorreo($correo)) {
            return [
                "estado" => false,
                "mensaje" => "El correo ya está registrado."
            ];
        }

        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO usuarios 
                (nombre, apellido, usuario, correo, password_hash, sexo)
                VALUES 
                (:nombre, :apellido, :usuario, :correo, :password_hash, :sexo)";

        $stmt = $this->db->prepare($sql);

        $stmt->bindParam(":nombre", $nombre);
        $stmt->bindParam(":apellido", $apellido);
        $stmt->bindParam(":usuario", $usuario);
        $stmt->bindParam(":correo", $correo);
        $stmt->bindParam(":password_hash", $passwordHash);
        $stmt->bindParam(":sexo", $sexo);

        if ($stmt->execute()) {
            return [
                "estado" => true,
                "mensaje" => "Usuario registrado correctamente.",
                "usuario_id" => $this->db->lastInsertId()
            ];
        }

        return [
            "estado" => false,
            "mensaje" => "No se pudo registrar el usuario."
        ];
    }

    public function obtenerPorCorreo($correo)
    {
        $correo = Sanitizador::limpiarCorreo($correo);

        $sql = "SELECT * FROM usuarios WHERE correo = :correo";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":correo", $correo);
        $stmt->execute();

        return $stmt->fetch();
    }

    public function guardarSecret2FA($usuarioId, $secret)
    {
        $sql = "UPDATE usuarios 
                SET secret_2fa = :secret 
                WHERE id = :id";

        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":secret", $secret);
        $stmt->bindParam(":id", $usuarioId);

        return $stmt->execute();
    }

    public function confirmar2FA($usuarioId)
{
    $sql = "UPDATE usuarios 
            SET fa_confirmado = 1 
            WHERE id = :id";

    $stmt = $this->db->prepare($sql);
    $stmt->bindParam(":id", $usuarioId);

    return $stmt->execute();
}
}