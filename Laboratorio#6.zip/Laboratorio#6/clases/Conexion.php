<?php

class Conexion
{
    private static $host = "localhost";
    private static $dbname = "lab_2fa";
    private static $user = "lab2fa";
    private static $pass = "123456";
    private static $conexion = null;

    public static function conectar()
    {
        if (self::$conexion === null) {
            try {
                $dsn = "mysql:host=" . self::$host . ";dbname=" . self::$dbname . ";charset=utf8mb4";

                self::$conexion = new PDO($dsn, self::$user, self::$pass);
                self::$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$conexion->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

            } catch (PDOException $e) {
                die("Error de conexión: " . $e->getMessage());
            }
        }

        return self::$conexion;
    }
}