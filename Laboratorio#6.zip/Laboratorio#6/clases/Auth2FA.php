<?php

require_once __DIR__ . "/../vendor/autoload.php";
require_once __DIR__ . "/RegistroUsuario.php";

use Sonata\GoogleAuthenticator\GoogleAuthenticator;
use Sonata\GoogleAuthenticator\GoogleQrUrl;

class Auth2FA
{
    private $g;
    private $registroUsuario;

    public function __construct()
    {
        $this->g = new GoogleAuthenticator();
        $this->registroUsuario = new RegistroUsuario();
    }

    public function generarSecret()
    {
        return $this->g->generateSecret();
    }

    public function guardarSecret($usuarioId, $secret)
    {
        return $this->registroUsuario->guardarSecret2FA($usuarioId, $secret);
    }

    public function generarQR($correo, $secret)
    {
        $app = "Lab2FA";

        return GoogleQrUrl::generate($correo, $secret, $app);
    }

    public function verificarCodigo($secret, $codigo)
    {
        $codigo = Sanitizador::limpiarCodigo2FA($codigo);

        return $this->g->checkCode($secret, $codigo);
    }

    public function confirmarActivacion($usuarioId)
{
    return $this->registroUsuario->confirmar2FA($usuarioId);
}
}