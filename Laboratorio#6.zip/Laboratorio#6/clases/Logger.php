<?php

require_once __DIR__ . "/Conexion.php";

class Logger
{
    public static function registrar($correo, $accion, $estado)
    {
        $db = Conexion::conectar();

        $sql = "INSERT INTO logs_sistema 
                (correo, accion, estado)
                VALUES 
                (:correo, :accion, :estado)";

        $stmt = $db->prepare($sql);
        $stmt->bindParam(":correo", $correo);
        $stmt->bindParam(":accion", $accion);
        $stmt->bindParam(":estado", $estado);

        return $stmt->execute();
    }
}