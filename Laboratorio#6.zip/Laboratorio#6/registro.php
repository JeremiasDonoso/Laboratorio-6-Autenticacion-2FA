<?php
session_start();
require_once "clases/CSRFProtection.php";

$error = "";

if (isset($_SESSION["error"])) {
    $error = $_SESSION["error"];
    unset($_SESSION["error"]);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro 2FA</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

<div class="contenedor">
    <h1>Registro de Usuario</h1>

    <?php if (!empty($error)): ?>
        <div class="error">
            <?= htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form action="procesar_registro.php" method="POST">
        <?= CSRFProtection::campoHidden(); ?>

        <input type="text" name="nombre" placeholder="Nombre" required>
        <input type="text" name="apellido" placeholder="Apellido" required>
        <input type="text" name="usuario" placeholder="Usuario" required>
        <input type="email" name="correo" placeholder="Correo electrónico" required>

        <select name="sexo" required>
            <option value="">Seleccione sexo</option>
            <option value="M">Masculino</option>
            <option value="F">Femenino</option>
        </select>

        <input type="password" name="password" placeholder="Contraseña" maxlength="16" required>
        <input type="password" name="confirmar_password" placeholder="Confirmar contraseña" maxlength="16" required>

        <button type="submit">Registrarse</button>
    </form>

    <p>
        ¿Ya tienes cuenta?
        <a href="login.php">Iniciar sesión</a>
    </p>
</div>

</body>
</html>