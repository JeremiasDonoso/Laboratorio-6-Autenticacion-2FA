<?php
session_start();

require_once "clases/CSRFProtection.php";
require_once "clases/RegistroUsuario.php";
require_once "clases/Auth2FA.php";
require_once "clases/Logger.php";

CSRFProtection::verificarFormulario();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: registro.php");
    exit;
}

$registro = new RegistroUsuario();

$resultado = $registro->registrar(
    $_POST["nombre"] ?? "",
    $_POST["apellido"] ?? "",
    $_POST["usuario"] ?? "",
    $_POST["correo"] ?? "",
    $_POST["password"] ?? "",
    $_POST["confirmar_password"] ?? "",
    $_POST["sexo"] ?? ""
);

if (!$resultado["estado"]) {
    $_SESSION["error"] = $resultado["mensaje"];

    Logger::registrar(
        $_POST["correo"] ?? "desconocido",
        "Intento de registro fallido: " . $resultado["mensaje"],
        "fallido"
    );
    header("Location: registro.php");
    exit;
}

$auth2fa = new Auth2FA();

$usuarioId = $resultado["usuario_id"];
$correo = $_POST["correo"];

$secret = $auth2fa->generarSecret();
$auth2fa->guardarSecret($usuarioId, $secret);

$qr = $auth2fa->generarQR($correo, $secret);

$_SESSION["registro_exitoso"] = true;
$_SESSION["usuario_id"] = $usuarioId;
$_SESSION["nombre_usuario"] = $_POST["nombre"];
$_SESSION["usuario_id_registrado"] = $usuarioId;
$_SESSION["correo_registrado"] = $correo;
$_SESSION["secret_2fa"] = $secret;
$_SESSION["qr_2fa"] = $qr;
$_SESSION["fase_registro_2fa"] = true;

Logger::registrar(
    $correo,
    "Registro exitoso y generación de secret 2FA",
    "exitoso"
);

header("Location: verificar_2fa.php");
exit;